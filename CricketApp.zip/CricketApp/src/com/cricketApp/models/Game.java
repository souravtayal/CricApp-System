package com.cricketApp.models;

public interface Game {
	void runAppView() ; 
}